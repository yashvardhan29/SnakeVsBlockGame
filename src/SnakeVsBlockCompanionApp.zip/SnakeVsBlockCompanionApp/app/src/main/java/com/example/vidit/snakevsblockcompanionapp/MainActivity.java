package com.example.vidit.snakevsblockcompanionapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firebaseDatabase  = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    public void right(View view) { databaseReference.child("foo").child("move").setValue(1);}

    public void left(View view) { databaseReference.child("foo").child("move").setValue(-1);}

    public void st(View view) { databaseReference.child("foo").child("move").setValue(0);}


    public void controlOn(View view) {databaseReference.child("foo").child("control").setValue(1);}

    public void controlOff(View view) {databaseReference.child("foo").child("control").setValue(0);}

}
